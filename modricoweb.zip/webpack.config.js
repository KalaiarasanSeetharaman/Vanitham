var webpack = require('webpack');
const path = require('path');
var BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;
const UglifyJsPlugin = require('uglifyjs-webpack-plugin')
module.exports = {
     entry: [
      //'script-loader!jquery/dist/jquery.min.js',
      './app/app.jsx'
    ],
   /* externals:{
      jquery:'jQuery'
    },*/
    plugins:[

     new webpack.DefinePlugin({
		  PRODUCTION: JSON.stringify(true),
		  VERSION: JSON.stringify("5fa3b9"),
		  BROWSER_SUPPORTS_HTML5: true,
		  TWO: "1+1",
		  "typeof window": JSON.stringify("object")
	}),
      /*new webpack.ProvidePlugin({
          '$': 'jquery',
          'jQuery': 'jquery',
           "window.jQuery": "jquery",
          'Popper': 'popper.js'
        }),*/
    ],
    output: {
       path: __dirname,
       filename: './web/bundle.js'
    },
    resolve: {
      alias: {
      "UnauthorizedLayout":path.resolve(__dirname, "app/components/layout/UnauthorizedLayout.jsx"),
       "Main":path.resolve(__dirname, "app/components/layout/Main.jsx"),
       "MainHome":path.resolve(__dirname, "app/components/layout/MainHome.jsx"),
       "Dashboard":path.resolve(__dirname, "app/components/layout/Dashboard.jsx"),
       "PostIssue":path.resolve(__dirname, "app/components/User/PostIssue.jsx"),
       "Header":path.resolve(__dirname, "app/components/layout/Header.jsx"),
       "Sidebar":path.resolve(__dirname, "app/components/layout/Sidebar.jsx"),
       "Footer":path.resolve(__dirname, "app/components/layout/Footer.jsx"),
       "Home":path.resolve(__dirname, "app/components/Home.jsx"),
       //"ListComponent":path.resolve(__dirname, "app/components/Listcomponent.jsx"),
       "Servicescomponent":path.resolve(__dirname, "app/components/Servicescomponent.jsx"),
       "Contribution":path.resolve(__dirname, "app/components/Contribution.jsx"),
       "Application":path.resolve(__dirname, "app/components/Application.jsx"),
       "Testimonals":path.resolve(__dirname, "app/components/Testimonals.jsx"),
       "Login":path.resolve(__dirname, "app/components/User/Login.jsx"),
       "loginAction": path.resolve(__dirname, "app/actions/login.jsx"),
       "forgetPassAction": path.resolve(__dirname, "app/actions/Forgetpassword.jsx"),
       "signupAction": path.resolve(__dirname, "app/actions/Signup.jsx"),
       "postAction": path.resolve(__dirname, "app/actions/Post.jsx"),
       "loginReducer": path.resolve(__dirname, "app/reducers/login.jsx"),
       "forgetPassReducer": path.resolve(__dirname, "app/reducers/Forgetpassword.jsx"),
       "signupReducer": path.resolve(__dirname, "app/reducers/Signup.jsx"),
       "postReducer": path.resolve(__dirname, "app/reducers/Post.jsx"),

       "SignupPopup":path.resolve(__dirname, "app/components/User/SignupPopup.jsx"),
       "Signup":path.resolve(__dirname, "app/components/User/Signup.jsx"),
       "Forgetpassword":path.resolve(__dirname, "app/components/User/Forgetpassword.jsx"),
       //"actions": path.resolve(__dirname, "app/actions/lists.jsx"),
       //"reducers": path.resolve(__dirname, "app/reducers/lists.jsx"),
       "configureStore": path.resolve(__dirname, "app/store/configureStore.jsx"),
       "userAPI": path.resolve(__dirname, "app/services/v1/userapi.jsx"),
       "basecss": path.resolve(__dirname, "app/styles/base.css"),
       "maincss": path.resolve(__dirname, "app/styles/main.css"),
       "media-queriescss": path.resolve(__dirname, "app/styles/media-queries.css"),
       "customcss": path.resolve(__dirname, "app/styles/custom.css"),
       "custom_mediacss": path.resolve(__dirname, "app/styles/custom_media.css"),
       'DeleteButton':path.resolve(__dirname, "app/components/Delete.jsx"),
       'DeleteButton':path.resolve(__dirname, "app/components/Delete.jsx"),
       "PostIssue":path.resolve(__dirname, "app/components/User/PostIssue.jsx"),
     },
      extensions: ['*', '.js', '.jsx']
    },
    module: {
      loaders: [
        {
          loader: 'babel-loader',
          query: {
            presets: ['react', 'es2015', 'stage-0'],
            plugins:['transform-decorators-legacy']
          },
          test: /\.jsx?$/,
          exclude: /(node_modules|bower_components)/
        },
        { test: /\.css$/, exclude: /(node_modules|bower_components)/, loader: "style-loader!css-loader" },
        {test: /\.(scss|css)$/, include: /node_modules/, loaders: [  'style-loader', 'css-loader', 'sass-loader' ]},
        {
            test: /\.(png|jpg|jpeg|gif)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,
            loader: 'file-loader?name=public/images/[name].[ext]',
        }, {
            test: /\.(wav|mp3|pdf)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,
            loader: 'file-loader',
        },
        /*{
            test: /\.(eot|svg|ttf|woff|woff2)$/,
            loader: 'file-loader?name=[path][name].[ext]'
        }*/

        /*{
          test: /\.(jpe?g|png|woff|woff2|eot|ttf|svg)(\?[a-z0-9=.]+)?$/, 
          loader: 'url-loader?limit=100000'
        }*/

        {
          test: /\.(eot|svg|ttf|woff|woff2)(\?v=\d+\.\d+\.\d+)?$/,
          loader: "url-loader",
          options: {
            limit: 100000000000000,
            name: "./web/fonts/[name].[ext]"
        }
      }

      ]
    }/*,

  devtool:'cheap-module-eval-source-map'*/
};
