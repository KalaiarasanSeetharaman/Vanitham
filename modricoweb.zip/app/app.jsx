import React from 'react'
import ReactDOM from 'react-dom'
import {BrowserRouter as Router, Switch, Redirect,  Route, Link} from 'react-router-dom'
import { browserHistory } from 'react-router'


import AuthorizedRoute from './AuthorizedRoute'

//// Layouts
import Main from 'Main'
import UnauthorizedLayout from 'UnauthorizedLayout'
import Dashboard from 'Dashboard'
import PostIssue from 'PostIssue'


import Home from 'Home'
import Signup  from 'Signup';


//Node Module Js Importing 
//import 'popper.js/dist/umd/popper'
//import 'bootstrap/dist/js/bootstrap'



//Node Module Css Importing
//import 'font-awesome/css/font-awesome.css'
//import "bootstrap/dist/css/bootstrap.css"

//import 'owl.carousel/dist/assets/owl.carousel.css';

import 'owl.carousel';



//Custom Style Importing
/*import "basecss";
import "maincss";
import "media-queriescss";
import "customcss";
import "custom_mediacss";*/

//import "./js/jquery-migrate-1.2.1.min.js";
//import "./js/jquery.flexslider.js";
/*import "./js/jquery.fittext.js";
import "./js/backstretch.js";
import "./js/waypoints.js";
import "./js/main.js";
import "./js/custom.js";*/


import {AUTHENTICATE_THE_USER}  from 'loginAction';

// Importing Provider Component
var {Provider} = require('react-redux');

// Requiring  Acctions for Listing functionality 
//var actions = require('actions');

// Importing Storeconfig for all component 
var store = require('configureStore').configure();

const token = sessionStorage.getItem('token');
if (token) {
    store.dispatch({ type: AUTHENTICATE_THE_USER });
    //browserHistory.path('/dashboard')
}

if (token) {
	ReactDOM.render(
		<Provider store={store}>
		  <Router basename='/demo'>
			    <div>
			    	<Switch>
			    		<AuthorizedRoute path="/" component={Main} />
			      	</Switch>
			    </div>
		  </Router>
		 </Provider>,
	  document.getElementById('app')
	);
}else{
	ReactDOM.render(
	<Provider store={store}>
	  <Router basename='/demo'>
		    <div>
		    	<Switch>
		    		<UnauthorizedLayout>
			      		<Route path="/" exact component={Home} />
				        <Route path="/signup" component={Signup} />
				     </UnauthorizedLayout>
		      	</Switch>
		    </div>
	  </Router>
	 </Provider>,
  document.getElementById('app')
  );
}