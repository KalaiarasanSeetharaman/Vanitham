/***Importing Axios Lib for Async Method For Getting Data From Api***/
var axios = require('axios');

/***Api Url***/
//var rootElement = document.getElementsByClassName('Listings');
//var url = rootElement.getAttribute('api-url');
import { apiConstant } from '../../constants';

//const APP_URL = "http://modrico.com/demo/";
const APP_URL = apiConstant.API_URL;
module.exports = {
  getCountries: function () {
      var requestUrl = `${APP_URL}countries`;
      var authOptions = {
            method: 'GET',
            url: requestUrl,
          /*  headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },*/
            json: true
      };
      return axios(authOptions)
      .then(function (response) {
         return response.data.data;
      })
      .catch(function (error) {
        return error.response.data.message;
      });
  },


  getCites: function (country_id) {
      var requestUrl = `${APP_URL}countries/${country_id}/cities`;
      var authOptions = {
            method: 'GET',
            url: requestUrl,
          /*  headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },*/
            json: true
      };
      return axios(authOptions)
      .then(function (response) {
         return response.data.data;
      })
      .catch(function (error) {
        return error.response.data.message;
      });
  },


  getSettings: function () {
      var requestUrl = `${APP_URL}settings`;
      var authOptions = {
            method: 'GET',
            url: requestUrl,
          /*  headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },*/
            json: true
      };
      return axios(authOptions)
      .then(function (response) {
        return response.data.data;
      })
      .catch(function (error) {
        return error.response.data.message;
      });
  },


   Userlogin: function (emailid, password) {
      var requestUrl = `${APP_URL}drivers/login`;
      var authOptions = {
            method: 'PUT',
            url: requestUrl,
            data: {'email':emailid,'password':password},
          /*  headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },*/
            json: true
      };
      return axios(authOptions)
      .then(function (response) {
         return response.data;
      })
      .catch(function (error) {
        return error.response.data.message;
      });
  },

  signUp: function (email,first_name,last_name,country_id,city_id,mobile_code,mobile_number
,company_id,password,confirm_password,device_type,device_token) {
      var requestUrl = `${APP_URL}drivers/signup`;
      var authOptions = {
            method: 'POST',
            url: requestUrl,
            data: {'email':email,'first_name':first_name,'last_name':last_name,'country_id':country_id,'city_id':city_id,'mobile_code':mobile_code,'mobile_number':mobile_number
,'company_id':company_id,'password':password,'confirm_password':confirm_password,'device_type':device_type,'device_token':device_token},
          /*  headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },*/
            json: true
      };
      return axios(authOptions)
      .then(function (response) {
        console.log(response.data);
         return response.data;
      })
      .catch(function (error) {
        return error.response.data.message;
      });
  },
  

  ForgetPassword: function (emailid) {
      var requestUrl = `${APP_URL}drivers/forgot_password`;
      var authOptions = {
            method: 'PUT',
            url: requestUrl,
            data: {'email':emailid},
          /*  headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },*/
            json: true
      };
      return axios(authOptions)
      .then(function (response) {
         return response.data;
      })
      .catch(function (error) {
        return error.response.data.message;
      });
  },


  getCategories: function (driver_code) {
      var requestUrl = `${APP_URL}drivers/${driver_code}/categories`;
      var authOptions = {
            method: 'GET',
            url: requestUrl,
          /*  headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },*/
            json: true
      };
      return axios(authOptions)
      .then(function (response) {
         return response.data.data;
      })
      .catch(function (error) {
        return error.response.data.message;
      });
  },



  addIssue: function (driver_code,post_category_name,required_amount,issue_description,attached_file) {
      var requestUrl = `${APP_URL}drivers/${driver_code}/posts`;
      let formData = new FormData();
        formData.append('description', issue_description)
        formData.append('remarks', 0)
        formData.append('category', post_category_name)
        formData.append('estimated_amount', required_amount)
        formData.append('image', attached_file)

      var authOptions = {
            method: 'POST',
            url: requestUrl,
            data:formData,
            //data: {'description':issue_description,'category':post_category_name,'estimated_amount':required_amount,'attached_image':attached_file},
            headers: {
                'Content-Type': 'multipart/form-data'
            },
            json: true
      };
      return axios(authOptions)
      .then(function (response) {
        console.log(response.data);
         return response.data;
      })
      .catch(function (error) {
        return error.response.data.message;
      });
  },

}