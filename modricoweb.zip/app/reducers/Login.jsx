/***
Default State for this reducer will be {isLoading:false,lists: '',status: false,error: ''}
It will change when action trigger for changing the state
When state it will change the store also
List Reducer for Sending State to Store Whenever Action Trigger ***/

const initialState = {
  isLoading:false,
  authenticated: false,
  status:'',
  error: '',
  message:'',
}

export var loginReducer = (state = initialState, action) => {
  switch (action.type) {

    case 'RESET_STATE':
     return { 
          ...state,
          status:'',
          error: ''
    };

    case 'GET_LOGGED_USER':
      return { 
          ...state,
          isLoading:action.loading 
    };

    case 'AUTHENTICATE_THE_USER':
      return { 
           ...state,
          status: true,
          authenticated:true ,
          isLoading:false
    };

    case 'AUTHENTICATE_USER_FAIL':
      return { 
          ...state,
          status: false,
          authenticated:false,
          isLoading:false,
          error:action.errorMessage
     };

    default:
      return state;
  };
};




