/***
Default State for this reducer will be {isLoading:false,lists: '',status: false,error: ''}
It will change when action trigger for changing the state
When state it will change the store also
List Reducer for Sending State to Store Whenever Action Trigger ***/

const initialState = {
  isLoading:false,
  status:'',
  error: '',
  message:'',
}

export var forgetpasswordReducer = (state = initialState, action) => {
  switch (action.type) {

    case 'RESET_STATE':
     return { 
          ...state,
          status:'',
          error: ''
    };

    case 'GET_FORGETPASSWORD':
      return { 
          ...state,
          isLoading:action.loading 
    };

    case 'FORGETPASSWORD_SUCCESS':
      return { 
           ...state,
          status: true,
          isLoading:false,
          message:action.message
    };

    case 'FORGETPASSWORD_SUCCESS':
      return { 
           ...state,
          status: true,
          isLoading:false
    };

    case 'FORGETPASSWORD_FAIL':
      return { 
          ...state,
          status: false,
          isLoading:false,
          error:action.errorMessage
     };

    default:
      return state;
  };
};




