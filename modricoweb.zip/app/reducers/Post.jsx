/***
Default State for this reducer will be {isLoading:false,lists: '',status: false,error: ''}
It will change when action trigger for changing the state
When state it will change the store also
List Reducer for Sending State to Store Whenever Action Trigger ***/

const initialState = {
  isLoading:false,
  status:'',
  error: '',
  category_lists:'',
  message:''
}

export var postReducer = (state = initialState, action) => {
  switch (action.type) {

    case 'RESET_STATE':
     return { 
          status:'',
          error: ''
    };

    case 'GET_USER':
      return { 
          ...state,
          isLoading:action.loading 
    };

    case 'ADD_ISSUE_OPTION':
      return { 
          ...state,
          isLoading:action.loading 
    };

    case 'ADD_ISSUE_OPTION_OVER':
      return { 
          ...state,
          isLoading:action.loading 
    };

    case 'ADD_ISSUE_SUCCESS':
      return { 
           ...state,
          status: true,
          isLoading:false,
          message:action.message
    };

    case 'CATEGORY_LISTS':
      return { 
          ...state,
          category_lists: action.list,
          country_status: true,
          isLoading:false
     };
     
    case 'ADD_ISSUE_FAIL':
      return { 
          ...state,
          status: false,
          isLoading:false,
          error:action.errorMessage
     };

    default:
      return state;
  };
};




