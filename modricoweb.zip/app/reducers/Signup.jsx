/***
Default State for this reducer will be {isLoading:false,lists: '',status: false,error: ''}
It will change when action trigger for changing the state
When state it will change the store also
List Reducer for Sending State to Store Whenever Action Trigger ***/

const initialState = {
  isLoading:false,
  status:'',
  error: '',
  country_lists:'',
  message:'',
  country_status:'',
  driver_for_lists:'',
  driver_for_status:'',
  country_code_lists:'',
  country_code_status:'',
  city_lists:'',
  city_status:'',


}

export var signUpReducer = (state = initialState, action) => {
  switch (action.type) {

    case 'RESET_STATE':
     return { 
          ...state,
          status:'',
          error: ''
    };

    case 'GET_USER':
      return { 
          ...state,
          isLoading:action.loading 
    };

    case 'SIGN_UP_OPTION':
      return { 
          ...state,
          isLoading:action.loading 
    };

    case 'SIGN_UP_OPTION_OVER':
      return { 
          ...state,
          isLoading:action.loading 
    };

    case 'SIGNUP_SUCCESS':
      return { 
           ...state,
          status: true,
          isLoading:false
    };

    case 'COUNTRY_LISTS':
      return { 
          ...state,
          country_lists: action.list,
          country_status: true,
     };

     case 'DRIVER_LISTS':
     return { 
          ...state,
          driver_for_lists: action.list,
          driver_for_status: true,
     };

    case 'COUNTRY_CODE':
     return { 
          ...state,
          country_code_lists: action.list,
          country_code_status: true,
     };

     case 'CITY_LISTS':
     return { 
          ...state,
          city_lists: action.list,
          city_status: true,
          isLoading:false,
     };

     

    case 'SIGNUP_USER_FAIL':
      return { 
          ...state,
          status: false,
          isLoading:false,
          error:action.errorMessage
     };

    default:
      return state;
  };
};




