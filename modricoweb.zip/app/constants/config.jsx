export const apiConstant = {
   API_URL: 'http://modrico.com/demo/api/web/index.php/v1/',

    //API_URL: 'http://192.168.43.104:1004/api/web/index.php/v1/',

    //BASE_URL: 'http://192.168.43.104:1004/',

    BASE_URL: 'http://modrico.com/demo/',


};