import React from 'react'
import ReactDOM from 'react-dom'
import {Route, Redirect} from 'react-router-dom'

import * as loginAction  from 'loginAction'; 

import { connect } from 'react-redux';

@connect((store)=>{
	return {pending: store.loginReducer.status,logged: store.loginReducer.authenticated};
})

export default class AuthorizedRoute extends React.Component {

  componentWillMount() {
  	const { dispatch } = this.props;
  	const token = localStorage.getItem('token');
	if (token) {
	    dispatch(loginAction.loginSuccess());
	    //browserHistory.path('/dashboard')
	}
    
  }

  render() {
    const { component: Component, pending, logged, ...rest } = this.props
    
    return (
      <Route {...rest} render={props => {
        if (!pending) return <Redirect to="/" />
        return logged
          ? <Component {...props} />
          : <Redirect to="/" />
      }} />
    )
  }
}