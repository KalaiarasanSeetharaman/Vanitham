/*-----------------------------------------------------------------------------------
/*
/* Custom JS
/*
-----------------------------------------------------------------------------------*/  
$(document).ready(function(){


  $("div.bhoechie-tab-menu>div.list-group>a").click(function(e) {
      e.preventDefault();
      $(this).siblings('a.active').removeClass("active");
      $(this).addClass("active");
      var index = $(this).index();
      $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
      $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
  });

  /********Home Banner*********/
  $('.modrico_banner').owlCarousel({
      loop:true,
      autoplay:true,
      autoplayHoverPause:false,
      autoplayTimeout:3000,
      responsiveClass:true,
      animateOut: 'fadeOut',
      smartSpeed:450,
      center: true,
      responsive:{
          0:{
              items:1,
              mergeFit:true,
              nav:false,
              center: true,
              loop:true,
              dots:false,
          },
          600:{
              mergeFit:true,
              items:1,
              nav:false,
              center: true,
              loop:true,
              dots:false,
          },
          1000:{
              items:1,
              nav:false,
              dots:false,
              loop:true
          }
      }
    });


  /********Testimonals Slider*********/
   $('.testimonials_slider').owlCarousel({
      loop:true,
      autoplay:true,
      margin:50,
      autoplayHoverPause:true,
      responsiveClass:true,
      responsive:{
          0:{
              items:1,
              nav:false,
              loop:true,
              dots:false,
          },
          600:{
              items:1,
              nav:false,
              loop:true,
              dots:false,
          },
          1000:{
              items:3,
              nav:false,
              dots:false,
              loop:true
          }
      }
    });

   /******** Sign Up Pop *********/

  $('.popup_modal').on('click',function(e){
      e.preventDefault();
     });
});

$(window).trigger('resize').trigger('scroll');
