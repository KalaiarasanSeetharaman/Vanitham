/**Importing API and React Redux**/
import * as userAPI from 'userAPI'; 
import { connect } from 'react-redux'; 
import createHistory from 'history/createBrowserHistory'
/***Action For Sending Request For loading event for ajax call***/

const history = createHistory()

export var handleChange = () => {
  return {
    type: 'RESET_STATE',
  };
};



export var getSignUp = () => {
  return {
    type: 'GET_USER',
    loading:true
  };
};



export var signUpSuccess = () => {
  return {
    type: 'SIGNUP_THE_USER'
  };
};



/***
 Action for failure when api call fails
 ***/
export var signUpFail = (error) => {
  return {
    type: 'SIGNUP_USER_FAIL',
    errorMessage:error,
    loading:false
  };
};


export var getCountries = () => {
  return (dispatch, getState) => {
    userAPI.getCountries()
            .then(
                res => { 
                    dispatch(receviedlists(res.data));
                },
                error => {
                    dispatch(failure(error));
                }
            );

  };

/***
 Action for api calls
 ***/
export var signup = (emailid, password) => {
  /*return (dispatch, getState) => {
    userAPI.Userlogin(emailid, password)
            .then(
                res => { 
                    if(res.data){
                      dispatch(loginSuccess());
                      sessionStorage.setItem('token', res.data.code);
                      sessionStorage.setItem('email', res.data.email);
                      //history.push('/dashboard');
                       window.location = window.location.href+'dashboard';
                     }else{
                      dispatch(loginFail(res));
                      
                     }
                },
                error => {
                    dispatch(loginFail(error));
                }
            );

  };*/
};

