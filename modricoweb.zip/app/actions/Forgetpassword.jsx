/**Importing API and React Redux**/
import * as userAPI from 'userAPI'; 
import { connect } from 'react-redux'; 
import createHistory from 'history/createBrowserHistory'
/***Action For Sending Request For loading event for ajax call***/

const history = createHistory()

export var handleChange = () => {
  return {
    type: 'RESET_STATE',
  };
};



export var getforgetpassword = () => {
  return {
    type: 'GET_FORGETPASSWORD',
    loading:true
  };
};


export var forgetpasswordSuccess = (data,message) => {
  return {
    type: 'FORGETPASSWORD_SUCCESS',
    message:message
  };
};



/***
 Action for failure when api call fails
 ***/
export var forgetpasswordFail = (error) => {
  return {
    type: 'FORGETPASSWORD_FAIL',
    errorMessage:error,
    loading:false
  };
};

/***
 Action for api calls
 ***/
export var forgetpassword = (emailid) => {
  return (dispatch, getState) => {
    userAPI.ForgetPassword(emailid)
            .then(
                res => { 
                    if(res.data){
                      dispatch(forgetpasswordSuccess(res.data,res.message));
                      // window.location = window.location.href+'dashboard';
                     }else{
                      //dispatch(forgetpasswordSuccess(res.data,'Password for sent to your registered email address'));
                      dispatch(forgetpasswordFail(res));
                     }
                },
                error => {
                  //dispatch(forgetpasswordSuccess(res.data,'Password for sent to your registered email address'));
                  dispatch(forgetpasswordFail(error));
                }
            );

  };
};

