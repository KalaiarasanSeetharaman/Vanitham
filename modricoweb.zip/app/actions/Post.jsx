/**Importing API and React Redux**/
import * as userAPI from 'userAPI'; 
import { connect } from 'react-redux'; 
import createHistory from 'history/createBrowserHistory'
/***Action For Sending Request For loading event for ajax call***/

const history = createHistory()

export var handleChange = () => {
  return {
    type: 'RESET_STATE',
  };
};





export var IssueOptions = () => {
  return {
    type: 'ADD_ISSUE_OPTION',
    loading:true
  };
};

export var IssueOptionsOver = () => {
  return {
    type: 'ADD_ISSUE_OPTION_OVER',
    loading:false
  };
};


export var AddIssueSuccess = (message) => {
  return {
    type: 'ADD_ISSUE_SUCCESS',
    message:message
  };
};



/***
 Action for failure when api call fails
 ***/
export var AddIssueFail = (error) => {
  return {
    type: 'ADD_ISSUE_FAIL',
    errorMessage:error,
    loading:false
  };
};


export var categorylists = (lists) => {
  return {
    type: 'CATEGORY_LISTS',
    list:lists,
    errorMessage:'',
  };
};


export var getCategories = (driver_code) => { 
  return (dispatch, getState) => {
    userAPI.getCategories(driver_code)
            .then(
                res => { 
                    dispatch(categorylists(res));
                },
                error => {
                    dispatch(AddIssueFail(error));
                }
            );
          }
};

/***
 Action for api calls
 ***/
export var addIssue = (driver_code,post_category_name,required_amount,issue_description,attached_file) => {
  return (dispatch, getState) => {
    userAPI.addIssue(driver_code,post_category_name,required_amount,issue_description,attached_file)
            .then(
                res => { 
                    if(res){
                      dispatch(AddIssueSuccess(res.message));
                     }else{
                      dispatch(AddIssueFail(res));
                     }
                },
                error => {
                  dispatch(AddIssueFail(error));
                }
            );

  };
};