/**Importing API and React Redux**/
import * as userAPI from 'userAPI'; 
import { connect } from 'react-redux'; 
import createHistory from 'history/createBrowserHistory'
/***Action For Sending Request For loading event for ajax call***/
import { apiConstant } from '../constants';

const history = createHistory()

export var handleChange = () => {
  return {
    type: 'RESET_STATE',
  };
};



export var getLoggedUser = () => {
  return {
    type: 'GET_LOGGED_USER',
    loading:true
  };
};


export var AUTHENTICATE_THE_USER = 'AUTHENTICATE_THE_USER';
export var loginSuccess = () => {
  return {
    type: 'AUTHENTICATE_THE_USER'
  };
};



/***
 Action for failure when api call fails
 ***/
export var loginFail = (error) => {
  return {
    type: 'AUTHENTICATE_USER_FAIL',
    errorMessage:error,
    loading:false
  };
};

/***
 Action for api calls
 ***/
export var login = (emailid, password) => {
  return (dispatch, getState) => {
    userAPI.Userlogin(emailid, password)
            .then(
                res => { 
                    if(res.data){
                      dispatch(loginSuccess());
                      sessionStorage.setItem('token', res.data.code);
                      sessionStorage.setItem('email', res.data.email);
                      sessionStorage.setItem('driver_code', res.data.driver_code);
                      //history.push('/dashboard');
                       window.location = apiConstant.BASE_URL+'dashboard';
                     }else{
                      dispatch(loginFail(res));
                      
                     }
                },
                error => {
                    dispatch(loginFail(error));
                }
            );

  };
};

