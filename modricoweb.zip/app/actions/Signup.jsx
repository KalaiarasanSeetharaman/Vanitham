/**Importing API and React Redux**/
import * as userAPI from 'userAPI'; 
import { connect } from 'react-redux'; 
import createHistory from 'history/createBrowserHistory'
/***Action For Sending Request For loading event for ajax call***/

const history = createHistory()

export var handleChange = () => {
  return {
    type: 'RESET_STATE',
  };
};



export var getSignUp = () => {
  return {
    type: 'GET_USER',
    loading:true
  };
};

export var SignUpOptions = () => {
  return {
    type: 'SIGN_UP_OPTION',
    loading:true
  };
};

export var SignUpOptionsOver = () => {
  return {
    type: 'SIGN_UP_OPTION_OVER',
    loading:false
  };
};






export var signUpSuccess = () => {
  return {
    type: 'SIGNUP_SUCCESS'
  };
};



/***
 Action for failure when api call fails
 ***/
export var signUpFail = (error) => {
  return {
    type: 'SIGNUP_USER_FAIL',
    errorMessage:error,
    loading:false
  };
};


export var countrylists = (lists) => {
  return {
    type: 'COUNTRY_LISTS',
    list:lists,
    errorMessage:'',
  };
};

export var driverlists = (lists) => {
  return {
    type: 'DRIVER_LISTS',
    list:lists,
    errorMessage:'',
  };
};

export var citylists = (lists) => {
  return {
    type: 'CITY_LISTS',
    list:lists,
    errorMessage:'',
  };
};


export var countrycode = (lists) => {
  return {
    type: 'COUNTRY_CODE',
    list:lists,
    errorMessage:'',
  };
};

export var getCountries = () => { 
  return (dispatch, getState) => {
    userAPI.getCountries()
            .then(
                res => { 
                    dispatch(countrylists(res));
                },
                error => {
                    dispatch(signUpFail(error));
                }
            );
          }
};

export var getCity = (country_id) => { 
  return (dispatch, getState) => {
    userAPI.getCites(country_id)
            .then(
                res => { 
                    dispatch(citylists(res));
                },
                error => {
                    dispatch(signUpFail(error));
                }
            );
          }
};


export var getDriverFor = () => { 
  return (dispatch, getState) => {
    userAPI.getSettings()
            .then(
                res => { 
                    dispatch(driverlists(res.companies));
                    dispatch(countrycode(res.countries));
                    dispatch(SignUpOptionsOver());
                },
                error => {
                    dispatch(signUpFail(error));
                }
            );
          }
};


/***
 Action for api calls
 ***/
export var signUp = (email,first_name,last_name,country_id,city_id,mobile_code,mobile_number
,company_id,password,confirm_password,device_type,device_token) => {
  return (dispatch, getState) => {
    userAPI.signUp(email,first_name,last_name,country_id,city_id,mobile_code,mobile_number
,company_id,password,confirm_password,device_type,device_token)
            .then(
                res => { 
                    if(res.data){
                      dispatch(signUpSuccess(res.data,res.message));
                     }else{
                      dispatch(signUpFail(res));
                     }
                },
                error => {
                  dispatch(signUpFail(error));
                }
            );

  };
};