/***Importing React , React DOM, List Component***/
import React from 'react';
import ReactDOM from 'react-dom';
import * as loginAction  from 'loginAction'; 
import { apiConstant } from '../../constants';


export default class Header extends React.Component {

	constructor(props) {
        super(props);
        this.logOut = this.logOut.bind(this);
    }

	logOut(e){
		 e.preventDefault();
		 const { dispatch } = this.props;
		// dispatch(loginAction.handleChange());
		 sessionStorage.removeItem('token');
		 sessionStorage.removeItem('email');
		 window.location = apiConstant.BASE_URL;
	}
	render(){
		if(sessionStorage.getItem('token')){
			return(
				<header id="main-header">
				    <div className="row header-inner">
				        <div className="logo col-md-2">
				           <a className="smoothscroll" href={apiConstant.BASE_URL}></a>
				        </div>
				        <nav id="nav-wrap">         
				           <a className="mobile-btn" href="#nav-wrap" title="Show navigation">
				            <span className='menu-text'>Show Menu</span>
				            <span className="menu-icon"></span>
				           </a>
				          <a className="mobile-btn" href="#" title="Hide navigation">
				            <span className='menu-text'>Hide Menu</span>
				            <span className="menu-icon"></span>
				          </a>         
				           <ul id="nav" className="nav">
				              <li><a title="Post Your Issue" id="post_your_issue" alt="Post Your Issue" href="#" className="btn button button_yellow">Post Your Issue</a></li>
				              <li><a className="smoothscroll popup_modal" href="#login" onClick={this.logOut}>Logout</a></li>
				           </ul> 
				        </nav>       
				     </div>
				</header>
			);
		}else{
			return(
			<header id="main-header">
			    <div className="row header-inner">
			        <div className="logo col-md-2">
			           <a className="smoothscroll" href="#hero"></a>
			        </div>
			        <nav id="nav-wrap">         
			           <a className="mobile-btn" href="#nav-wrap" title="Show navigation">
			            <span className='menu-text'>Show Menu</span>
			            <span className="menu-icon"></span>
			           </a>
			          <a className="mobile-btn" href="#" title="Hide navigation">
			            <span className='menu-text'>Hide Menu</span>
			            <span className="menu-icon"></span>
			          </a>         
			           <ul id="nav" className="nav">
			              <li><a title="Post Your Issue" id="post_your_issue" alt="Post Your Issue" href="#" className="btn button button_yellow">Post Your Issue</a></li>
			              <li><a className="smoothscroll popup_modal" data-toggle="modal" data-dismiss="modal" data-target="#signinpopup" href="#login">Login</a></li>
			              <li><a className="smoothscroll popup_modal" data-toggle="modal" data-dismiss="modal" data-target="#signuppopup" href="#Sign Up">Sign Up</a></li>
			           </ul> 
			        </nav>       
			     </div>
			</header>
		);
		}
	}
}
