/***Importing React , React DOM, List Component***/
import React from 'react';
import ReactDOM from 'react-dom';
import Header from 'Header';
import Home from 'Home'
import Footer from 'Footer';
import Login  from 'Login';
import Signup  from 'Signup';
import SignupPopup  from 'SignupPopup';
import Forgetpassword from 'Forgetpassword';
import { apiConstant } from '../../constants';

import {Switch, Route, Redirect, Link, withRouter, Router} from 'react-router-dom'

import { history } from 'history'

//export const history = createHashHistory()

import { connect } from 'react-redux';
@connect((store)=>{
	return {login: store.loginReducer,forgetPassWord:store.forgetPassReducer,signup: store.signUpReducer};
})

/***In Main Component Including Our <ListComponent apiUrl={this.props.apiUrl} onEventHandle={this.eventMethod}></ListComponent> Listing Component With onEventHandle Property
 by eventMethod***/
class UnauthorizedLayout extends React.Component {


	
	constructor(props,context) {
        super(props,context);
        
       this.state = {
            userEmail: '',
        }; 
        //history.push("/signup");
        this.handleStepTwo = this.handleStepTwo.bind(this); 
    }

	handleStepTwo(email_id){
		this.setState({ userEmail: email_id });
		sessionStorage.setItem('signupemail', email_id);
		//this.props.history.push("/");
		//history.push("/signup")
		window.location= apiConstant.BASE_URL+"signup";
	}
	
	render(){
		const { login, forgetPassWord, signup  } = this.props;
		const { userEmail } = this.state;
		if(login.isLoading==false && forgetPassWord.isLoading==false && signup.isLoading==false ){
			 $('body').addClass('loaded');
		}else{
			$('body').removeClass('loaded');
		}
		return(
			<div>
			   <div id="preloader"> 
			     <div id="status">
			         <img src="/images/loader.gif" height="60" width="60" alt=""/>
			         <div className="loader">Loading...</div>
			      </div>
			   </div>
			   <div id="loader-wrapper">
					<div id="loader"></div>
					<div className="loader-section section-left"></div>
		            <div className="loader-section section-right"></div>
				</div>
			   <Header />
		        {this.props.children}
		       <Footer />
		       <Login/>
		       <SignupPopup steopOnefinish={this.handleStepTwo}/>
		       <Forgetpassword/>
			 </div>
		);
	}
}

export default UnauthorizedLayout;