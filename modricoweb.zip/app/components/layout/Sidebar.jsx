/***Importing React , React DOM, List Component***/
import React from 'react';
import ReactDOM from 'react-dom';
import { apiConstant } from '../../constants';
import { NavLink } from 'react-router-dom'


export default class Sidebar extends React.Component {

	constructor(props) {
        super(props);
    }
	render(){
			return(
					
						<nav className="cd-side-nav">
							<ul>
								<li className="">
									<NavLink to="/dashboard" className="side_menu hvr-bounce-to-right"  activeClassName="active">
										<i className="fa fa-dashboard nav_icon "></i>
										<span className="nav-label">Dashboard</span> 
									</NavLink>
								</li>
								<li>
									<NavLink to="/post-issue" className="side_menu hvr-bounce-to-right"  activeClassName="active">
										<i className="fa fa-th nav_icon "></i>
										<span className="nav-label">Post your issue</span> 
									</NavLink>
								</li>
								<li>
									<NavLink to="/post-list" className="side_menu hvr-bounce-to-right"  activeClassName="active">
										<i className="fa fa-list nav_icon "></i>
										<span className="nav-label">Post List</span> 
									</NavLink>
								</li>
								<li>
									<NavLink to="/profile-view" className="side_menu hvr-bounce-to-right"  activeClassName="active">
										<i className="fa fa-user nav_icon "></i>
										<span className="nav-label">Profile View</span> 
									</NavLink>
								</li>
								<li>
									<NavLink to="/change-password" className="side_menu hvr-bounce-to-right"  activeClassName="active">
										<i className="fa fa-unlock nav_icon "></i>
										<span className="nav-label">Change Password</span> 
									</NavLink>
								</li>
							</ul>
						</nav>
						
				);
		}
}
