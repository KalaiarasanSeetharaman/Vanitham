/***Importing React , React DOM, List Component***/
import React from 'react';
import ReactDOM from 'react-dom';

import { Switch, Route, Redirect } from 'react-router-dom'


import Header from 'Header';
import Sidebar from 'Sidebar';
import Home from 'Home';
import Dashboard from 'Dashboard';
import PostIssue from 'PostIssue';

import Footer from 'Footer';


import { connect } from 'react-redux';
import { apiConstant } from '../../constants';
@connect((store)=>{
	return {login: store.loginReducer,forgetPassWord:store.forgetPassReducer,postIssue:store.postReducer};
})

/***In Main Component Including Our <ListComponent apiUrl={this.props.apiUrl} onEventHandle={this.eventMethod}></ListComponent> Listing Component With onEventHandle Property
 by eventMethod***/
class Main extends React.Component {
	
	
	render(){
		const { login, forgetPassWord, postIssue} = this.props;

		if(login.isLoading==false && forgetPassWord.isLoading==false && postIssue.isLoading==false){
			 $('body').addClass('loaded');
		}else{
			$('body').removeClass('loaded');
		}
			if(window.location != apiConstant.BASE_URL){
			return(

				<div>
				    <script src="/js/menumain.js"></script>
				   <div id="preloader"> 
				     <div id="status">
				         <img src="/images/loader.gif" height="60" width="60" alt=""/>
				         <div className="loader">Loading...</div>
				      </div>
				   </div>
				   <div id="loader-wrapper">
						<div id="loader"></div>
						<div className="loader-section section-left"></div>
			            <div className="loader-section section-right"></div>
					</div>
				   <Header/>
				   <div className="cd-main-content">
				   	  <Sidebar/>
				   	  <div className="content-wrapper">
			            <main>
					      <Switch>
					        <Route path="/dashboard" component={Dashboard} />
					        <Route path="/post-issue" component={PostIssue} />
					      </Switch>
					    </main>
					    </div> 
				     </div>
			       <Footer/>
				 </div>
			);

		}else{
		return(
				<div>
				   <div id="preloader"> 
				     <div id="status">
				         <img src="/images/loader.gif" height="60" width="60" alt=""/>
				         <div className="loader">Loading...</div>
				      </div>
				   </div>
				   <div id="loader-wrapper">
						<div id="loader"></div>
						<div className="loader-section section-left"></div>
			            <div className="loader-section section-right"></div>
					</div>
				   <Header/>
				  	 <main>
				      <Switch>
				        <Route path="/" component={Home} />
				      </Switch>
				    </main>
			       <Footer/>
				 </div>
			);	
		}
	}
}

export default Main;