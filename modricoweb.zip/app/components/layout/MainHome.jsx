/***Importing React , React DOM, List Component***/
import React from 'react';
import ReactDOM from 'react-dom';

import { Switch, Route, Redirect } from 'react-router-dom'


import Header from 'Header';
import Sidebar from 'Sidebar';
import Home from 'Home';
import Dashboard from 'Dashboard';

import Footer from 'Footer';


import { connect } from 'react-redux';
@connect((store)=>{
	return {login: store.loginReducer,forgetPassWord:store.forgetPassReducer};
})

/***In Main Component Including Our <ListComponent apiUrl={this.props.apiUrl} onEventHandle={this.eventMethod}></ListComponent> Listing Component With onEventHandle Property
 by eventMethod***/
class MainHome extends React.Component {
	
	render(){
		const { login, forgetPassWord  } = this.props;

		if(login.isLoading==false && forgetPassWord.isLoading==false){
			 $('body').addClass('loaded');
		}else{
			$('body').removeClass('loaded');
		}
		return(
			<div>
			   <div id="preloader"> 
			     <div id="status">
			         <img src="/images/loader.gif" height="60" width="60" alt=""/>
			         <div className="loader">Loading...</div>
			      </div>
			   </div>
			   <div id="loader-wrapper">
					<div id="loader"></div>
					<div className="loader-section section-left"></div>
		            <div className="loader-section section-right"></div>
				</div>
			   <Header/>
			   {this.props.children}
		       <Footer/>
			 </div>
		);
	}
}

export default MainHome;