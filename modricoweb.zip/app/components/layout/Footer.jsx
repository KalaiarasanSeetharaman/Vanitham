/***Importing React , React DOM, List Component***/
import React from 'react';
import ReactDOM from 'react-dom';
//import ListComponent from 'ListComponent'

/***In Main Component Including Our <ListComponent apiUrl={this.props.apiUrl} onEventHandle={this.eventMethod}></ListComponent> Listing Component With onEventHandle Property
 by eventMethod***/
export default class Footer extends React.Component {
	render(){
		return(
			<footer>
			      <div className="row top_footer" id="footer_top">  
			        <div className="col-md-12 paddmarg">     
			         <div className="eight columns paddmarg col-md-8 tab-whole footer-about footer-left">
			           
			         </div>
			         <div className="four col-md-5 columns tab-whole left-cols footer_right">
			            <div className="row">
			               <div className="columns">
			                  <h3 className="title">About Modrico</h3>
			                  <hr />
			                  <img src="/images/logo-aboutus.png"/>
			                  <p>
			                  Lorem Ipsum is simply dummy text of the printing and typesetting industry.
			                  </p>    
			                   <ul className="payment_gateway">
			                    <li><a href="#"><img src="/images/paypal.png"/></a></li>
			                    <li><a href="#"><img src="/images/visa.png"/></a></li>
			                    <li><a href="#"><img src="/images/mastercard.png"/></a></li>
			                    <li><a href="#"><img src="/images/rupay.png"/></a></li>
			                  </ul>              
			               </div>             
			            </div> 
			         </div>
			         <div className="eight columns col-md-8 tab-whole">
			            <ul className="site_link">
			              <li><a href="#">Home</a></li>
			              <li><a href="#">About Us</a></li>
			              <li><a href="#">Our Services</a></li>
			              <li><a href="#">Testimonials</a></li>
			              <li><a href="#">Contact Us</a></li>
			              <li><a href="#">Terms and Conditions</a></li>
			              <li><a href="#">Privacy Policy</a></li>
			            </ul> 
			         </div> 
			              
			         <div id="go-top">
			            <a className="smoothscroll" title="Back to Top" href="#top_page"><span>Top</span><i className="fa fa-long-arrow-up"></i></a>
			         </div>
			       </div>
			      </div> 
			      <div className="row  copyright_footer">
			        <div className="col-md-12 col-sm-12 col-xs-12 ">
			            <div className="col-md-6 col-sm-12 col-xs-12">
			                <p className="copyright">&copy; Copyright 2017 Modrico.com</p>
			            </div>

			            <div className="col-sm-12 mobile_view col-xs-12 hidden-md">
			                <ul className="social_link">
			                <li><a href="#"><img src="/images/facebook.png"/></a></li>
			                <li><a href="#"><img src="/images/google+.png"/></a></li>
			                <li><a href="#"><img src="/images/twitter.png"/></a></li>
			              </ul> 

			            </div>
			            <div className="col-md-6 desktop_view pull-right hidden-xs">
			               <ul className="social_link">
			                <li><a href="#"><img src="/images/facebook.png"/></a></li>
			                <li><a href="#"><img src="/images/google+.png"/></a></li>
			                <li><a href="#"><img src="/images/twitter.png"/></a></li>
			              </ul> 
			            </div>
			        </div>
			      </div>
			   </footer> 
		);
	}
}
