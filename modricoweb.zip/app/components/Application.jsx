import React from 'react';
import ReactDOM from 'react-dom';


export default class Application extends React.Component {
	render(){
		return(
			<section id="application">
			    <div className="row section-head">
			      <div className="twelve columns">
			           <h1 className="headding_underline">WE HAVE  <span className="head_yellow">APPLICATION</span></h1>
			           <hr />
			           <img src="/images/app_screenshot.jpg"/>
			        </div>
			      </div>             
			</section> 
		);
	}
}