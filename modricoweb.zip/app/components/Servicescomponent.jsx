import React from 'react';
import ReactDOM from 'react-dom';


export default class Servicescomponent extends React.Component {
	render(){
		return(
			<section id="services">
			    <div className="row section-head">
			      <div className="twelve columns">
			            <div className="row">
			              <div className="twelve columns three_gird">
			                  <h1 className="headding_underline">TOP <span className="head_yellow">ISSUE</span> CATEGORIES</h1>
			                   <hr />
			                  <div className="service-list bgrid-third s-bgrid-half mob-bgrid-whole">
			                    <div className="bgrid ">
			                         <div className="icon-part">
			                             <img title="Post Your Issues"  alt="Post Your Issues" src="/images/caraccident.jpg"/>
			                         </div>
			                         <h3>CAR ACCIDENT</h3>
			                         <div className="service-content">                    
			                           <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium
			                          </p> 
			                        </div>      
			                    </div>     
			                    <div className="bgrid">
			                         <div className="icon-part">
			                             <img title="Post Your Issues"  alt="Post Your Issues" src="/images/healthissues.jpg"/>
			                         </div>
			                         <h3>Health Issue</h3>
			                         <div className="service-content">                    
			                           <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium
			                          </p> 
			                        </div>      
			                    </div> 
			                    <div className="bgrid">
			                         <div className="icon-part">
			                             <img title="Post Your Issues"  alt="Post Your Issues" src="/images/service.jpg"/>
			                         </div>
			                         <h3>Service</h3>
			                         <div className="service-content">                    
			                           <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium
			                          </p> 
			                        </div>      
			                    </div>         
			                  </div> 
			                </div> 
			            </div> 
			           <div className="row">
			                <div className="twelve columns">
			                  <div className="service-list bgrid-one s-bgrid-half mob-bgrid-whole">
			                    <h1 className="headding_underline">CONTRIBUTE <span className="head_yellow">YOUR</span> FELLOW DRIVER</h1>
			                   <hr />
			                    <div className="bgrid1">
			                         <div className="icon-part">
			                             <img title="Post Your Issues"  alt="Post Your Issues" src="/images/john.jpg"/>
			                         </div>
			                         
			                         <div className="service-content single_gird">                    
			                           <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium
			                          </p> 
			                        </div>
			                    </div>         
			                  </div> 
			                </div> 
			            </div> 
			        </div>
			      </div>             
			</section> 
		);
	}
}