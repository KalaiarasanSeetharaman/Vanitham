import React from 'react';
import ReactDOM from 'react-dom';


export default class Testimonals extends React.Component {
	render(){
		return(
				<section id="testimonials">
				    <div className="container-fluid">
				      <div className="col-md-12">
				           <h1 className="headding_underline text-center our_driver_says">OUR DRIVER  <span className="head_yellow">COMMUNITY SAYS</span></h1>
				           <hr className="" />
				           <div id="testimonials_slider" className="testimonials_slider owl-carousel owl-theme">
			           			<div className="slide-item">
					                <div className="inner">
					                    <div className="upper-content">
					                        <div className="text">“If you are looking at blank cassettes on the web, you may be very confused at the difference in fair price.”</div>
					                        <div className="rating"><img src="/images/4_star.png"/></div>
					                    </div>
					                    <div className="info">
					                        <figure className="author-thumb img-circle">
					                        <img width="70" height="70" src="/images/testimonial_user.png" className="img-circle wp-post-image" alt=""/></figure>
					                        <h4>Jannat Fardaous.</h4>
					                        <div className="location">From Florida</div>
					                    </div>
					                </div>
					            </div>
					            <div className="slide-item">
									<div className="inner">
										<div className="upper-content">
											<div className="text">“If you are looking at blank cassettes on the web, you may be very confused at the difference in fair price.”</div>
											<div className="rating"><img src="/images/4_star.png"/></div>
										</div>
										<div className="info">
											<figure className="author-thumb img-circle">
											<img width="70" height="70" src="/images/testimonial_user.png" className="img-circle wp-post-image" alt=""/></figure>
											<h4>Jannat Fardaous.</h4>
											<div className="location">From Florida</div>
										</div>
									</div>
								</div>
								<div className="slide-item">
									<div className="inner">
										<div className="upper-content">
											<div className="text">“If you are looking at blank cassettes on the web, you may be very confused at the difference in fair price.”</div>
											<div className="rating"><img src="/images/3_star.png"/></div>
										</div>
										<div className="info">
											<figure className="author-thumb img-circle"><img width="70" height="70" src="/images/testimonial_user.png" className="img-circle wp-post-image" alt=""/></figure>
											<h4>Jannat Fardaous.</h4>
											<div className="location">From Florida</div>
										</div>
									</div>
								</div>
								<div className="slide-item">
									<div className="inner">
										<div className="upper-content">
											<div className="text">“If you are looking at blank cassettes on the web, you may be very confused at the difference in fair price.”</div>
											<div className="rating"><img src="/images/3_star.png"/></div>
										</div>
										<div className="info">
											<figure className="author-thumb img-circle"><img width="70" height="70" src="/images/testimonial_user.png" className="img-circle wp-post-image" alt=""/></figure>
											<h4>Jannat Fardaous.</h4>
											<div className="location">From Florida</div>
										</div>
									</div>
								</div>
								<div className="slide-item">
									<div className="inner">
										<div className="upper-content">
											<div className="text">“If you are looking at blank cassettes on the web, you may be very confused at the difference in fair price.”</div>
											<div className="rating"><img src="/images/4_star.png"/></div>
										</div>
										<div className="info">
											<figure className="author-thumb img-circle"><img width="70" height="70" src="/images/testimonial_user.png" className="img-circle wp-post-image" alt=""/></figure>
											<h4>Jannat Fardaous.</h4>
											<div className="location">From Florida</div>
										</div>
									</div>
								</div>					            
				           </div>
				        </div>
				      </div>             
				</section> 
				 
		);
	}
}