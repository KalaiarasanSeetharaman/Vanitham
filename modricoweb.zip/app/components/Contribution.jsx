import React from 'react';
import ReactDOM from 'react-dom';


export default class Contribution extends React.Component {
	render(){
		return(
			<section id="start_your_contribution">
			    <div className="row section-head">
			      <div className="twelve columns">
				  <h2>Become a <span className="head_yellow">MO</span>bile <span className="head_yellow">DR</span>iver <span className="head_yellow">CO</span>mmunity</h2>
				  <p>Join your hand with us for a better life and beautiful future.</p>
			           <a title="Start Your Contribuition" href="#" className="button button_yellow stroke smoothscroll">Start Your Contribuition</a>
			        </div>
			      </div>             
			 </section> 
		);
	}
}